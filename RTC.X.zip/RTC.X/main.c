/*
 * File:   main.c
 * Author: Administrator
 *
 * Created on 29 December, 2020, 3:46 PM
 */


#include "config.h" // Send PIC 16f877a configuration
#include "lcd.h"  //call LCD Functons
#include "I2C.h"  // Call I2C Functions
#include"RTC.h"  // Call RTC functions

int main() {

    Init_LCD(); // start LCD function
    InitI2C();  // Initialize I2C bus function
      // Set RTC  Time
    Set_DS1307_RTC_Time(AM_Time,11, 28, 59);
     // Set RTC Date
    Set_DS1307_RTC_Date(30,8,20, Sunday`);  
    while(1)
    {
        Lcd_Clear();     
        Lcd_Set_Cursor(0x80);
        Lcd_Write_String("  Welcome  ");
        Lcd_Set_Cursor(0xC0);
        Lcd_Write_String(" Microdigisoft ");
       __delay_ms(50);           //   50ms Delay.
       // Display RTC time on first line of LCD
        DisplayTimeToLCD(Get_DS1307_RTC_Time());
        // Display RTC date on second line of LCD
        DisplayDateOnLCD(Get_DS1307_RTC_Date());
         __delay_ms(200);    //200 ms delay           
          }
    return 0;           
}