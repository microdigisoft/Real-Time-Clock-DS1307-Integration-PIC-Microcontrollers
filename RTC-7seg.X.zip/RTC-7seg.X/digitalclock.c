/*
 * File:   digitalclock.c
 * Author: microdigisoft
 *
 * Created on 5 September, 2020, 3:57 PM
 */
#include <stdio.h>
#include <stdlib.h>
#include "config.h" // Set PIC 16f1517 configuration
#include "I2C.h"  //Call I2C Functions
#include "RTC.h"  // Call RTC functions

int main() {

   
    InitI2C();  // Initialize I2C bus function
      // Set RTC  Time
    //Set_DS1307_RTC_Time(AM_Time,11, 28, 59);
     // Set RTC Date
    //Set_DS1307_RTC_Date(30,8,20, Sunday`);  
    while(1)
    {
     
       __delay_ms(50);           //   50ms Delay.
       // Display RTC time on first line of LCD
       // DisplayTimeToLCD(Get_DS1307_RTC_Time());
        // Display RTC date on second line of LCD
        //DisplayDateOnLCD(Get_DS1307_RTC_Date());
         __delay_ms(200);    //100 ms delay           
          }
    return 0;           
}

