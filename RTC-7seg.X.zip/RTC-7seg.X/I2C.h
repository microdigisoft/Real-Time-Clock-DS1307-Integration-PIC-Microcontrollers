/* 
 * File:   I2C.h
 * Author: microdigisoft
 *
 * Created on 30 August, 2020, 11:45 AM
 */

#ifndef I2C_H
#define	I2C_H

#ifdef	__cplusplus
extern "C" {
#endif
#define SDA  PORTCbits.RC4      // Data pin for i2c
#define SCK  PORTCbits.RC3       // Clock pin for i2c
#define SDA_DIR  TRISCbits.TRISC4     // Data pin direction
#define SCK_DIR  TRISCbits.TRISC3      // Clock pin direction
#define I2C_SPEED_FACTOR	1	// Low value means low i2c frequency	
#define I2C_SPEED  100        // kbps
#define Crystal_Value		12  // MHz
#define HalfBitDelay 		(500*Crystal_Value)/(12*I2C_SPEED_FACTOR)
// Define macros
#define Set_SDA_Low	  PORTCbits.RC4=0
#define Set_SDA_High  PORTCbits.RC4=1
#define Set_SCK_Low	  PORTCbits.RC3=0
#define Set_SCK_High  PORTCbits.RC3=1
// i2C Function Declarations
void InitI2C(void);
void I2C_Start(void);
void I2C_ReStart(void);
void I2C_Stop(void);
void I2C_Send_ACK(void);
void I2C_Send_NACK(void);
bit  I2C_Write_Byte(unsigned char);
unsigned char I2C_Read_Byte(void);



#ifdef	__cplusplus
}
#endif

#endif	/* I2C_H */

