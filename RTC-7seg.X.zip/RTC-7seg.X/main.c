/*
 * File:   main.c
 * Author: Administrator
 *
 * Created on 29 December, 2020, 4:58 PM
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "config.h" // Send PIC 16f1517 configuration
#include "I2C.h"  // Call I2C Functions
#include"RTC.h"  // Call RTC functions
#define digit1 PORTCbits.RC0
#define digit2 PORTCbits.RC1
#define digit3 PORTCbits.RC2
#define digit4 PORTCbits.RC5
char H1,M1; //BCD data
char DH1,DH2,DM1,DM2; // RTC Digits for display   
unsigned char hexvalue[10]= {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
unsigned int i ,j;
int main(){
   unsigned int i ,j;       //  DATA pin FOR LCD 8bits  port D as output   
    TRISD=0;         // Direction for Port D
    TRISC=0;
    digit1 = 1; //set direction of port C bit0
    digit2 = 1; //set direction of port C bit1
    digit3 = 1; //set direction of port C bit2
    digit4 = 1; //set direction of port C bit5
    InitI2C();  // Initialize I2C bus function
      // Set RTC  Time
    Set_DS1307_RTC_Time(AM_Time,11, 28, 59);
     // Set RTC Date
    Set_DS1307_RTC_Date(30,8,20, Sunday`);  
    while(1)
    {  
    Read_Bytes_From_DS1307_RTC(0x00, pRTCArray, 3); //Read the RTC to get Sec, Min & Hours
    // Read and Convert Minutes back from BCD into number
	M1 = pRTCArray[1];
	pRTCArray[1] = (M1>>4)*10 + (M1&0x0F); 
    // Read and Convert Hours back from BCD into number
	if(pRTCArray[2]&0x40)	// if 12 hours mode
	{
		if(pRTCArray[2]&0x20)	// if PM Time
			pRTCArray[3] = PM_Time;
		else		// if AM time
			pRTCArray[3] = AM_Time;

		H1 = pRTCArray[2];
		pRTCArray[2] = ((H1&0x1F)>>4)*10 + (H1&0x0F);
	}
	else		// if 24 hours mode
	{
		H1 = pRTCArray[2];
		pRTCArray[2] = (H1>>4)*10 + (H1&0x0F);
		pRTCArray[3] = TwentyFourHoursMode;
    }
      DH1= (pRTCArray[2]/10)+0x30; //Hours 10th Digit
      DH2= (pRTCArray[2]%10)+0x30; //Hour 1st digit
      DM1= (pRTCArray[1]/10)+0x30; //Min 10th Digit
      DM2= (pRTCArray[1]%10)+0x30; //Min 1st Digit
	  unsigned char str1[5]; // store hours and min digit is in single array
	  str1[0] = DH1;
      str1[1] = DH2;
      str1[2] = DM1; 
      str1[3] = DM2; 
      str1[5]="/0";
     i= atoi(str1);     //convert RTC digits into integer
       unsigned int a1,a2,a3,a4;
            a1 = i / 1000;   // holds 1000's digit
            a2 = ((i/100)%10); // holds 100's digit
            a3 = ((i/10)%10);  // holds 10th digit
            a4 = (i%10);  // holds unit digit value  
            
 PORTD=hexvalue[a1]; // send 1000's place data to fourth digit
digit1=0;   //  turn on forth display unit
__delay_ms(1);
digit1=1;   //  turn off forth display unit
PORTD=hexvalue[a2];  // send 100's place data to 3rd digit
digit2=0;   //  turn on 3rd display unit
__delay_ms(1);
digit2=1;  //  turn off 3rd display unit
PORTD=hexvalue[a3];  // send 10th place data to 2nd digit
digit3 = 0;  //  turn on 2nd display unit
__delay_ms(1);
 digit3 = 1;   //  turn off 2nd display unit
PORTD=hexvalue[a4];  // send unit place data to 1st digit
digit4 = 0;  //  turn on 1st display unit
__delay_ms(1);
digit4 = 1;  //  turn off 1st display unit
 }         
}
